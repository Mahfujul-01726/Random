<?php
// Connect to MySQL
$servername = "localhost";
$username = "root";
$password = "";
$database = "registration_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Get POST data and sanitize
$name = htmlspecialchars($_POST['name']);
$father_name = htmlspecialchars($_POST['father_name']);
$mother_name = htmlspecialchars($_POST['mother_name']);
$address = htmlspecialchars($_POST['address']);
$mobile = htmlspecialchars($_POST['mobile']);
$email = htmlspecialchars($_POST['email']);
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

// Insert into DB
$sql = "INSERT INTO users (name, father_name, mother_name, address, mobile, email, password)
        VALUES (?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssss", $name, $father_name, $mother_name, $address, $mobile, $email, $password);

if ($stmt->execute()) {
    echo "Registration successful!";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
