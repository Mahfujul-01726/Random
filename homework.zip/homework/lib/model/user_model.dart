class UserModel {
  String name;
  int age;
  String imageUrl;

  UserModel({required this.name, required this.age, required this.imageUrl});
}
