import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'view/user_profile_page.dart';

void main() {
  runApp(GetMaterialApp(home: UserProfilePage()));
}
