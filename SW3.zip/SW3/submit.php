<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "form_data";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form values
$name = $_POST['name'];
$age = $_POST['age'];
$gender = $_POST['gender'];
$address = $_POST['address'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];

// Insert query
$sql = "INSERT INTO users (name, age, gender, address, email, mobile)
        VALUES ('$name', $age, '$gender', '$address', '$email', '$mobile')";

if ($conn->query($sql) === TRUE) {
    echo "✅ Data submitted successfully!";
} else {
    echo "❌ Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
