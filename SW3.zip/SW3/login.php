<?php
session_start();

$DB = "form_data";
$USER = "root";
$PASSWORD = "";
$HOST = "localhost";

$connect = mysqli_connect($HOST, $USER, $PASSWORD, $DB);
if (!$connect) {
    echo "Not Connected";
}

if (isset($_POST['submit'])) {
    $Email = $_POST['uname'];
    $Password = $_POST['psw'];

    // Get the user record from the database
    $query = "SELECT * FROM users WHERE email='$Email'";
    $data = mysqli_query($connect, $query);
    $total = mysqli_num_rows($data);
    
    if ($total == 1) {
        $user = mysqli_fetch_assoc($data);
        // Verify the password using password_verify since we stored a hashed password
        if (password_verify($Password, $user['password'])) {
            $_SESSION['email'] = $Email;
            header("Location: profile.html");
            exit;
        } else {
            echo "<script>alert('Invalid Password');</script>";
        }
    } else {
        echo "<script>alert('Email not found');</script>";
    }


}
?>
