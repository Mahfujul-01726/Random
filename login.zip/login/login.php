<?php
    session_start();
    $DB = "implements";
    $USER = "root";
    $PASSWORD = "";
    $HOST = "localhost";
    $connect = mysqli_connect($HOST, $USER, $PASSWORD, $DB);
    if (!$connect) {
        echo "Not Connected";
    } else {
        echo " ";
    }

    if (isset($_POST['submit'])) {
        $Email = $_POST['uname'];
        $Password = $_POST['psw'];

        $query = "select * from student where email='$Email' && password='$Password'";
        $data = mysqli_query($connect, $query);
        $total = mysqli_num_rows($data);

        if ($total == 1) {
            echo "<script>alert('Login Successful')</script>";
        } else {
            echo "<script>alert('Invalid E-mail or Password')</script>";
        }
    }
?>
